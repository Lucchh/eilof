# EILOF: An Efficient Incremental Local Outlier Factor Algorithm for Data Streaming

[![MIT License](https://img.shields.io/badge/license-MIT-green)](https://choosealicense.com/licenses/mit/)

EILOF (Efficient Incremental Local Outlier Factor) is a Python package designed to detect outliers in data streams efficiently. Based on the research paper *"An Efficient Outlier Detection Algorithm for Data Streaming"* (publication forthcoming), this library provides a robust and scalable implementation for detecting anomalies in real-time data.

---

## Table of Contents
- [Features](#-features)
- [Installation](#-installation)
- [Getting Started](#-getting-started)
- [Documentation](#-documentation)
- [Dataset Example](#-dataset-example)
- [Contributing](#-contributing)
- [Issues](#-issues)
- [License](#️-license)


## 📚 Features

- **Incremental Updates**: Efficiently updates Local Outlier Factor (LOF) scores when new data points are streamed.
- **High Performance**: Optimized for computational efficiency, making it suitable for large-scale datasets and streaming scenarios.
- **Customizable Parameters**: Adjustable number of nearest neighbors (`k`) for outlier detection.
- **Ease of Use**: Minimal setup and intuitive API.

---

## 🛠 Installation

To install the EILOF package, use the following command:

```bash

pip install eilof

```

🚀 Getting Started
Here’s a quick example to get you started:

```bash
import numpy as np
from eilof import EILOF

# Example dataset
data = np.random.rand(1000, 5)  # 1000 data points with 5 features
new_data = np.random.rand(100, 5)  # 100 new points to stream

# Initialize the EILOF model
model = EILOF(k=20)

# Fit the model with the initial dataset
model.fit(data)

# Stream new data and update the model
lof_scores = model.update(new_data)

# Detect outliers
outlier_labels = model.predict_labels(threshold=95)

print("Outlier labels:", outlier_labels)
```

📖 Documentation
Class: EILOF

Methods:
	1.	fit(data)
Fits the model to the initial dataset.
	2.	update(new_points)
Updates the model incrementally with new streaming data.
	3.	predict_labels(threshold=95, include_reference=True)
Predicts outlier labels for the data based on a specified percentile threshold.
	4.	predict_reference_labels(threshold=95)
Predicts outlier labels for the reference dataset.

Utility Functions:
	1.	reachability_distance(dist_matrix, k): Calculates the reachability distance matrix.
	2.	local_reachability_density(reachability_dist, neighbors): Computes local reachability density (LRD).
	3.	lof_srs(dist_matrix, neighbors, lrd, k): Computes LOF scores.



⚖️ License

This project is licensed under the MIT License. See the [LICENSE](./LICENSE) file for details.



📊 Dataset Example: [Credit Card Fraud Detection Dataset](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud).

Here’s how you can use the EILOF package with the Credit Card Fraud Detection Dataset:

```bash

import pandas as pd
from sklearn.preprocessing import StandardScaler
from eilof import EILOF

# Load dataset (example)
data = pd.read_csv('creditcard.csv')

# Preprocess data
scaler = StandardScaler()
features = scaler.fit_transform(data.drop(columns=['Class']))
labels = data['Class']

# Split into reference and streaming datasets
reference_data = features[:2000]
streaming_data = features[2000:3000]

# Initialize and fit the EILOF model
model = EILOF(k=50)
model.fit(reference_data)

# Update model with streaming data
lof_scores = model.update(streaming_data)
outlier_labels = model.predict_labels(threshold=95)

print("Outlier labels for streaming data:", outlier_labels)

```

💡 Contributing

We welcome contributions! Please fork the repository and submit a pull request with your changes. Ensure all tests pass before submitting.

🐞 Issues

If you encounter any issues or have feature requests, feel free to submit them [here](https://github.com/Lucchh/eilof/issues).